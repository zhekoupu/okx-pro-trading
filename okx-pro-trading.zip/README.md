
# OKX Professional Trading System v3.0

Institutional-grade OKX perpetual futures signal system.
- Mainstream coin filtering
- Risk-controlled position sizing
- Telegram signal delivery
- Designed for 24/7 autonomous operation

## Quick Start
```bash
pip install -r requirements.txt
python main.py
```

## Configuration
Edit `config.py` and fill in your Telegram Bot Token and Chat ID.
