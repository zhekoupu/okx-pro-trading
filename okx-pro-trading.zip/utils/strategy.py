# strategy logic placeholder
